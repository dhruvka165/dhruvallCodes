#include<stdio.h>
int main(){

    float m1 = 95; // maths marks
    float m2 = 77; // physics marks
    float m3 = 92; // chemistry marks 
    float m4 = 90; // english marks
    float m5 = 86; // sanskrit marks
    float p = (m1+m2+m3+m4+m5)/5;
    printf("percentage of 5 subject is : %f",p);
    return 0;
}