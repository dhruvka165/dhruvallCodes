#include<stdio.h>
int main (){

    int l = 5;
    float a = l * l;
    printf("the area of square is: %f",a);
    return 0;
}