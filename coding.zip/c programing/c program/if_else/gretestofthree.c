#include<stdio.h>
int main(){
    int a;
    printf("please enter first number");
    scanf("%d",&a);
    int b;
    printf("please enter second number");
    scanf("%d",&b);
    int c;
    printf("please enter third number");
    scanf("%d"&c)
    if (a>b && b>c)
    {
        printf("your first number is greatest");
    }
    

}