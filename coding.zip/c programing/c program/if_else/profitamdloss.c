#include<stdio.h>
int main(){
     int x;
    printf("please enter buying price : ");
    scanf("%d",&x);    
    int y;
    printf("please enter selling price : ");
    scanf("%d",&y);
    int z;
    if (z=y-x ,y>x){
        printf("you are in profit of : %d",z);
    }
    else if (y<x)
    {
        printf("you are in loss of : %d",z);
    }
    else if (x=y)
    {
        printf("you are selling in bought price therefore no loss no profit");
    }
    
    
    
}

    