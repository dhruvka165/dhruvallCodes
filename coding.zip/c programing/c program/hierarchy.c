#include<stdio.h>
int main(){
    int i = 2*3/4+4/4+8-2+5/8;
    printf("%d",i);
    return 0;
}