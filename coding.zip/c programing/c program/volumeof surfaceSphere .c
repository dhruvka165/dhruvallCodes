#include<stdio.h>
int main(){

    int r = 7;
    float v = 4 * 3.14 * r * r * r / 3;
    printf("the volume is : %f",v);
    return 0;
}
