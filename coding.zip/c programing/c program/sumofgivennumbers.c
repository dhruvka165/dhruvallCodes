#include<stdio.h>
int main(){
    int x;
    printf("please enter first number");
    scanf("%d",&x);
    int y;
    printf("please enter second number");
    scanf("%d",&y);
     int sum = x+y;
     printf("your sum of number is %d",sum);
    
}